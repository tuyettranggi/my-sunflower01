// JavaScript Document
(function($){




			var ImageFilter = function(){
				var _self = "#MainView_Area";
				var Timer;
				var html;
				var Fname;
				var Vname;
				
				// controlがtrueの時に処理を開始する
				var control=false;
				this.check_action = function(){
					return control;
				}
				
				this.set_action =function(co){
					if(co == true){
						control = true;
					}else{
						control = false;
					}
				}
				
				this.cover = function(Vname,Vhtml,Vtime){
					if(control!=true){ return false; }		
					if(Vname){ Fname = Vname; }else{ return false; }				
					if(Vhtml){ html = Vhtml; }else{ return false; }		
					if(!isNaN(Vtime)){ Timer=Vtime;}		
					switch(Fname){
						case "MyFadeIn":
						case "101":
							this.MyFadeIn();
						break;																	
						
						default:
						this.MyFadeIn();		
					}
				}
			
				this.MyFadeIn = function(){		
					control=false;			
					//if(!Timer){ Timer=3000;}
					if($(_self+' div').size()==0){
						$(_self).wrapInner('<div></div>');
					}
					$(_self).append('<div>'+html+'</div>');
					$(_self+' div:eq(0)').css({'float':'left','position':'absolute','top':'0px','left':'0px','z-index':'20'});		
					$(_self+' div:eq(1)').css({'float':'left','position':'absolute','top':'0px','left':'0px','z-index':'10','opacity':'1'});
					$(_self+' div:eq(0)').animate({'opacity':0},{
						queue: true,
						duration: Timer,
						easing: "easeInOutQuart",
						complete: function(){
							$(_self+' div:eq(0)').remove();
							$(_self+' div:eq(0)').css({'z-index':'10'});
							control=true;		
						}
					});
				}	
			}

	
		var I = new ImageFilter();
		var control=true;








	$.fn.iiSlider = function(options) {
	
		$.fn.iiSlider.defaults = {
			Speed:0.5,
			Speed_m:3,
			TimeInterval:40,
			ScrollDirection:"down"
		};
		
		var o = $.extend({}, $.fn.iiSlider.defaults, options);









		
		return this.each(function(){
            var _self = this;
			var ImgCount = $('#ScrollArea li').length;//画像点数カウント
			var ImgHeight = $('#ScrollArea li').outerHeight();//画像の高さ取得
			$('#ScrollArea').css('height',(ImgCount+2)*ImgHeight+"px");//表示エリアの高さ
			$('#ScrollArea').css('top',"-"+ImgHeight+"px");//表示エリアの位置
			
			var y=0;//移動量
			var s=o.Speed;

			var Max_num = $('#Hidden_imgs li').length-1;//メイン画像の表示番号
			var num = 1;

			var over=0;//上下ボタンのマウスオーバー時のメイン画像の変更
			var n = 0;

			//タイマー
			var set_timer = function(time){
				timerID = setInterval(function(){
					if(o.ScrollDirection =="down"){
						timer_action_toD(time);				
					}else if(o.ScrollDirection =="top"){
						timer_action_toT(time);				
					}else{
						timer_action_toD(time);
					}
				},o.TimeInterval);
			}

			//タイマークリア
			var clear_timer=function(){
				clearInterval(timerID);
			}

			//下スクロール
			var timer_action_toD = function(time){
									//alert(y);
				if(y>=ImgHeight){
					$('#ScrollArea li:first').before($('#ScrollArea li:last').clone());
					$('#ScrollArea li:last').remove();
					y=0;
					num = num - 1;
					num = check_num(num);//n=num+1;
					n = num-1;//alert(n);
					if (n==-1) {n=5;}
					$('#ScrollArea li p').css('display','block');
					$('#ScrollArea li #image' + n).css('display','none');
					main_image_change(time);
					//Image_MouseOver();
				}
				y = y + s;
				$('#ScrollArea li').css('top',y+"px");
			}

			//上スクロール
			var timer_action_toT = function(time){
				if(y<=0){
					$('#ScrollArea li:last').after($('#ScrollArea li:first').clone());
					$('#ScrollArea li:first').remove();
					y= ImgHeight;
					num = num + 1;
					num = check_num(num);
					n = num-2;//alert(n);
					if (n==-2) {
						n=4;
					}
					if (n==-1) {
						n=5;
					}
					$('#ScrollArea li p').css('display','block');
					$('#ScrollArea li #image' + n).css('display','none');
					main_image_change_(time);
					//Image_MouseOver();			
				}		
				y = y - s;
				$('#ScrollArea li').css('top',y+"px");
			}

			//画像をクリックしたとき
			var Image_MouseOver = function(){
				/*$('#ScrollArea li img').bind('click',function(){
					num = $(this).attr('name');
					num = check_num(num);
					main_image_change_over();
				});*/
				
				/*$('#ScrollArea li').hover(function(){
					$(this).children('p').css('display','none');
				}, function(){
				    $(this).children('p').css('display','block');
				});*/
			}

			//メイン画像の表示番号チェック
			var check_num = function(num){
				num = parseInt(num);
				if(!isNaN(num)){
					if(num < 0){
						num = Max_num;
					}else if(num > Max_num){
						num = 0;
					}
					return num;	
				}else{
					return false;
				}		
			}

			//タイマーでの画像の切替
			var main_image_change = function(time){
				if(!isNaN(num) && over==0){			
				if(control==false){
					if(control==false){control = I.check_action();}
				}

				if(control==true){
					//フィルターのオブジェクトを呼び出す	
					Vhtml = $('#Hidden_imgs li:eq('+num+')').html();	
					Vname = $('#Hidden_imgs li:eq('+num+') input').val();
							
					if(Vname >= 100 && Vname < 200){
						I.set_action(true);		
						I.cover(Vname,Vhtml,time);
						control = I.check_action();	
					}else{
						I.set_action(true);
						I.cover("101",Vhtml,1000);
						control = I.check_action();					
					}
				}
				}else{
					return false;
				}			
			}
			
			
			var main_image_change_ = function(time){
				nu=num-1;//alert(nu);
				if (nu==-1) { nu=5; }
				if(!isNaN(nu) && over==0){			
				if(control==false){
					if(control==false){control = I.check_action();}
				}

				if(control==true){
					//フィルターのオブジェクトを呼び出す	
					Vhtml = $('#Hidden_imgs li:eq('+nu+')').html();	
					Vname = $('#Hidden_imgs li:eq('+nu+') input').val();
							
					if(Vname >= 100 && Vname < 200){
						I.set_action(true);		
						I.cover(Vname,Vhtml,time);
						control = I.check_action();	
					}else{
						I.set_action(true);
						I.cover("101",Vhtml,1000);
						control = I.check_action();					
					}
				}
				}else{
					return false;
				}			
			}

			//画像をクリックしたときの切替
			var main_image_change_over = function(){
				if(!isNaN(num)){		
					if(control==false){
						if(control==false){control = I.check_action();}
					}
						
					if(control==true){
						//フィルターのオブジェクトを呼び出す	
						Vhtml = $('#Hidden_imgs li:eq('+num+')').html();	
						Vname = "101";		
						
						I.set_action(true);
						I.cover("101",Vhtml,1000);
						control = I.check_action();
					}
				}else{
					return false;
				}			
			}

			//上のボタン制御
			$('#Topbtn').hover(function(){
				over=0;
				control = true;
				time = 0;
				clear_timer();
				s= o.Speed_m;
				o.ScrollDirection="top";
				set_timer(time);
			},
			function(){
				over=0;
				time = 1500;
				clear_timer();
				s= o.Speed;
				o.ScrollDirection="top";
				set_timer(time);			
			});

			//下ボタン制御
			$('#Bottombtn').hover(function(){
				over=0;
				control = true;
				time = 0;
				clear_timer();
				s= o.Speed_m;
				o.ScrollDirection="down";
				set_timer(time);
			},
			function(){
				over=0;
				time = 1500;
				clear_timer();
				s= o.Speed;
				o.ScrollDirection="down";
				set_timer(time);			
			});

			//スクロールエリアをマウスオーバーしたとき
			/*$('#ScrollArea').hover(function(){
				clear_timer();
			},
			function(){
				s= o.Speed;
				set_timer();			
			});*/

			//自動スタート開始
			if(Max_num==-1){
				$(_self).html();
			}else if(Max_num==0){
				$(_self).html($('#Hidden_imgs li').eq(num).html());
			}else{
				$(_self).html($('#Hidden_imgs li').eq(num).html());
				Image_MouseOver();
				set_timer();				
			}


		});

	}


})(jQuery);