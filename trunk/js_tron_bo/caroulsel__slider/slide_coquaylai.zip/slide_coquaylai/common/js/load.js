head.js(
   {jquery:'common/js/jquery-1.6.2.min.js'},
   {browser:'common/js/jquery.browser.min.js'},
   {easing:'common/js/jquery.easing-1.3.pack.js'},
   {iiSlider:'common/js/jquery.iiSlider.js'}
);
head.ready(function(){

	//targetBlank
	$("a.blank").click(function(){
		window.open(this.href);
		return false;
	});

	//scrollUp
	$("a[href^=#]").click(function() {  
		var hash = this.hash;  
		 if(!hash || hash == "#")  
		 return false;  
		$($.browser.safari ? 'body' : 'html')  
		 .animate({scrollTop: $(hash).offset().top}, 500, "swing");  
		 return false;  
	});

	//rollOver
	var rollOver = (function(){
		var preLoad = new Object();
		$('img.rollOver,input.rollOver').not("[src*='_on.']").each(function(){
			var imgSrc = this.src;
			var fType = imgSrc.substring(imgSrc.lastIndexOf('.'));
			var imgName = imgSrc.substr(0, imgSrc.lastIndexOf('.'));
			var imgOver = imgName + '_on' + fType;
			preLoad[this.src] = new Image();
			preLoad[this.src].src = imgOver;
			$(this).hover(
				function (){
					this.src = imgOver;
				},
				function (){
					this.src = imgSrc;
				}
			);
		});
	})();
	
	$('#MainView_Area').iiSlider();
});