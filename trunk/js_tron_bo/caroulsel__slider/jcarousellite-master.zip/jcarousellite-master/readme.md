jCarouselLite
=============

**jCarouselLite** jCarousel Lite is a jQuery plugin that carries you on a carousel ride filled with images and HTML content. Put simply, you can navigate images and/or HTML in a carousel-style widget. It is super light weight, at about 2 KB in size, yet very flexible and customizable to fit most of our needs. 

This is a fork of the library 


Changelog
---------
Fix to work with google closure compiler.


Further Information
--------------------

For more details, see the original [authors website](http://www.gmarwaha.com/jquery/jcarousellite/)

To build on Windows, run `build\build-windows.bat`.

License: See original authors site.