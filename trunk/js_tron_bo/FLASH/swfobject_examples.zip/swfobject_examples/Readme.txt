Read the following before using the files within this archive.1. This archive contains files that belong to the article, Detecting Flash Player versions and embedding SWF files with SWFObject 2, posted in the Adobe Flash Player Developer Center:http://www.adobe.com/devnet/flashplayer/articles/swfobject.html

The archive contains:
- All SWFObject 2 downloads as can be found on http://code.google.com/p/swfobject/
- The sample files used in the article
- The source .fla files for the examples2. Unpack the archive and put the files in any location of your choosing.