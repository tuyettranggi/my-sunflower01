$(function(){
	// rollover
	$('.imgover').each(function(){
		this.osrc = $(this).attr('src');
		this.rollover = new Image();
		this.rollover.src = this.osrc.replace(/(\.gif|\.jpg|\.png)/, "_o$1");
	}).hover(function(){
		$(this).attr('src',this.rollover.src);
	},function(){
		$(this).attr('src',this.osrc);
	});
	// scroll
	$('a[@href^=#]').click(function() {
		var $t = $(this.hash);
		if (this.hash.length > 1 && $t.size()) {
			$.scrollTo($t, 400);
			return false;
		}
	});
});
