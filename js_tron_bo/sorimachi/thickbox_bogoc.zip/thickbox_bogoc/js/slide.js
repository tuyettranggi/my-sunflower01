/* �a�� */

(function($){
	$(function(){
		var left = 0;
		var now = 0;
		var $border = $('<img/>').attr('src', 'images/border.gif').css({
			position: 'absolute',
			top: 0,
			left: 0,
			display: 'none'
		}).appendTo( $('.carousel01_images') );
		
		$('.carousel01_canvas').height( $('.carousel01_canvas img').height() );
		
		$('.carousel01_images li').each(function(index){
			$(this).children('a').click(function(){ return false; }).children('img').hover(function(){
				$(this).css({ opacity: 0.6 });
			},function(){
				$(this).css({ opacity: 1 });
			});
			$(this).children('a').attr('href').match(/([0-9]*)\.jpg/);
			var num = RegExp.$1;
			$(this).css({ left: (120 * index) + 'px' }).mouseover(function(){
				now = index;
				$('.carousel01_canvas img')
					.queue([])
					.css({ opacity: 0 })
					.attr({ src: 'images/work_img' + num + '.jpg' })
					.animate({ opacity: 1 }, 500);
				var offset = $(this).position();
				$border.css({
					top: offset.top + 'px',
					left: offset.left + 'px',
					opacity: 0
				}).queue([]).show().animate({ opacity: 1 }, 300);
				
				clearTimeout(timer);
				timer = setTimeout(move, second);
			});
		});
		$('.carousel01_left img').css({ cursor: 'pointer' }).click(function(){
			if ( left > 0 ) {
				$('.carousel01_images li').animate({
					left: '+=120'
				}, function(){
					$('.carousel01_images li:eq('+now+')').trigger('mouseover');
				});
				left--;
				now--;
			}
			return false;
		});
		$('.carousel01_right img').css({ cursor: 'pointer' }).click(function(){
			if ( left < $('.carousel01_images li').length - 5 ) {
				$('.carousel01_images li').animate({
					left: '-=120'
				}, function(){
					$('.carousel01_images li:eq('+now+')').trigger('mouseover');
				});
				left++;
				now++;
			}
			return false;
		});
		
		var move = function(){
			if ( now == $('.carousel01_images li').length - 1 ) {
				$('.carousel01_images li').each(function(index){
					$(this).animate({
						left: 120 * index
					}, function(){
						$('.carousel01_images li:eq('+now+')').trigger('mouseover');
					});
				});
				left = 0;
				now = 0;
			} else if ( left > $('.carousel01_images li').length - 6 ){
				now++;
				$('.carousel01_images li:eq('+now+')').trigger('mouseover');
			} else if ( now < left + 2 ) {
				now++;
				$('.carousel01_images li:eq('+now+')').trigger('mouseover');
			} else {
				$('.carousel01_right img').trigger('click');
			}
		}
		var second = 8000;
		var timer = setTimeout(move, second);
	});
})(jQuery);


/* �m�� */


(function($){
	$(function(){
		var left = 0;
		var now = 0;
		var $border = $('<img/>').attr('src', 'images/border.gif').css({
			position: 'absolute',
			top: 0,
			left: 0,
			display: 'none'
		}).appendTo( $('.carousel02_images') );
		
		$('.carousel02_canvas').height( $('.carousel02_canvas img').height() );
		
		$('.carousel02_images li').each(function(index){
			$(this).children('a').click(function(){ return false; }).children('img').hover(function(){
				$(this).css({ opacity: 0.6 });
			},function(){
				$(this).css({ opacity: 1 });
			});
			$(this).children('a').attr('href').match(/([0-9]*)\.jpg/);
			var num = RegExp.$1;
			$(this).css({ left: (120 * index) + 'px' }).mouseover(function(){
				now = index;
				$('.carousel02_canvas img')
					.queue([])
					.css({ opacity: 0 })
					.attr({ src: 'images/work1_img' + num + '.jpg' })
					.animate({ opacity: 1 }, 500);
				var offset = $(this).position();
				$border.css({
					top: offset.top + 'px',
					left: offset.left + 'px',
					opacity: 0
				}).queue([]).show().animate({ opacity: 1 }, 300);
				
				clearTimeout(timer);
				timer = setTimeout(move, second);
			});
		});
		$('.carousel02_left img').css({ cursor: 'pointer' }).click(function(){
			if ( left > 0 ) {
				$('.carousel02_images li').animate({
					left: '+=120'
				}, function(){
					$('.carousel02_images li:eq('+now+')').trigger('mouseover');
				});
				left--;
				now--;
			}
			return false;
		});
		$('.carousel02_right img').css({ cursor: 'pointer' }).click(function(){
			if ( left < $('.carousel02_images li').length - 5 ) {
				$('.carousel02_images li').animate({
					left: '-=120'
				}, function(){
					$('.carousel02_images li:eq('+now+')').trigger('mouseover');
				});
				left++;
				now++;
			}
			return false;
		});
		
		var move = function(){
			if ( now == $('.carousel02_images li').length - 1 ) {
				$('.carousel02_images li').each(function(index){
					$(this).animate({
						left: 120 * index
					}, function(){
						$('.carousel02_images li:eq('+now+')').trigger('mouseover');
					});
				});
				left = 0;
				now = 0;
			} else if ( left > $('.carousel02_images li').length - 6 ){
				now++;
				$('.carousel02_images li:eq('+now+')').trigger('mouseover');
			} else if ( now < left + 2 ) {
				now++;
				$('.carousel02_images li:eq('+now+')').trigger('mouseover');
			} else {
				$('.carousel02_right img').trigger('click');
			}
		}
		var second = 8000;
		var timer = setTimeout(move, second);
	});
})(jQuery);


/* �ߑ� */
(function($){
	$(function(){
		var left = 0;
		var now = 0;
		var $border = $('<img/>').attr('src', 'images/border.gif').css({
			position: 'absolute',
			top: 0,
			left: 0,
			display: 'none'
		}).appendTo( $('.carousel03_images') );
		
		$('.carousel03_canvas').height( $('.carousel03_canvas img').height() );
		
		$('.carousel03_images li').each(function(index){
			$(this).children('a').click(function(){ return false; }).children('img').hover(function(){
				$(this).css({ opacity: 0.6 });
			},function(){
				$(this).css({ opacity: 1 });
			});
			$(this).children('a').attr('href').match(/([0-9]*)\.jpg/);
			var num = RegExp.$1;
			$(this).css({ left: (120 * index) + 'px' }).mouseover(function(){
				now = index;
				$('.carousel03_canvas img')
					.queue([])
					.css({ opacity: 0 })
					.attr({ src: 'images/work2_img' + num + '.jpg' })
					.animate({ opacity: 1 }, 500);
				var offset = $(this).position();
				$border.css({
					top: offset.top + 'px',
					left: offset.left + 'px',
					opacity: 0
				}).queue([]).show().animate({ opacity: 1 }, 300);
				
				clearTimeout(timer);
				timer = setTimeout(move, second);
			});
		});
		$('.carousel03_left img').css({ cursor: 'pointer' }).click(function(){
			if ( left > 0 ) {
				$('.carousel03_images li').animate({
					left: '+=120'
				}, function(){
					$('.carousel03_images li:eq('+now+')').trigger('mouseover');
				});
				left--;
				now--;
			}
			return false;
		});
		$('.carousel03_right img').css({ cursor: 'pointer' }).click(function(){
			if ( left < $('.carousel03_images li').length - 5 ) {
				$('.carousel03_images li').animate({
					left: '-=120'
				}, function(){
					$('.carousel03_images li:eq('+now+')').trigger('mouseover');
				});
				left++;
				now++;
			}
			return false;
		});
		
		var move = function(){
			if ( now == $('.carousel03_images li').length - 1 ) {
				$('.carousel03_images li').each(function(index){
					$(this).animate({
						left: 120 * index
					}, function(){
						$('.carousel03_images li:eq('+now+')').trigger('mouseover');
					});
				});
				left = 0;
				now = 0;
			} else if ( left > $('.carousel03_images li').length - 6 ){
				now++;
				$('.carousel03_images li:eq('+now+')').trigger('mouseover');
			} else if ( now < left + 2 ) {
				now++;
				$('.carousel03_images li:eq('+now+')').trigger('mouseover');
			} else {
				$('.carousel03_right img').trigger('click');
			}
		}
		var second = 8000;
		var timer = setTimeout(move, second);
	});
})(jQuery);

/* ���� */
(function($){
	$(function(){
		var left = 0;
		var now = 0;
		var $border = $('<img/>').attr('src', 'images/border.gif').css({
			position: 'absolute',
			top: 0,
			left: 0,
			display: 'none'
		}).appendTo( $('.carousel04_images') );
		
		$('.carousel04_canvas').height( $('.carousel04_canvas img').height() );
		
		$('.carousel04_images li').each(function(index){
			$(this).children('a').click(function(){ return false; }).children('img').hover(function(){
				$(this).css({ opacity: 0.6 });
			},function(){
				$(this).css({ opacity: 1 });
			});
			$(this).children('a').attr('href').match(/([0-9]*)\.jpg/);
			var num = RegExp.$1;
			$(this).css({ left: (120 * index) + 'px' }).mouseover(function(){
				now = index;
				$('.carousel04_canvas img')
					.queue([])
					.css({ opacity: 0 })
					.attr({ src: 'images/work3_img' + num + '.jpg' })
					.animate({ opacity: 1 }, 500);
				var offset = $(this).position();
				$border.css({
					top: offset.top + 'px',
					left: offset.left + 'px',
					opacity: 0
				}).queue([]).show().animate({ opacity: 1 }, 300);
				
				clearTimeout(timer);
				timer = setTimeout(move, second);
			});
		});
		$('.carousel04_left img').css({ cursor: 'pointer' }).click(function(){
			if ( left > 0 ) {
				$('.carousel04_images li').animate({
					left: '+=120'
				}, function(){
					$('.carousel04_images li:eq('+now+')').trigger('mouseover');
				});
				left--;
				now--;
			}
			return false;
		});
		$('.carousel04_right img').css({ cursor: 'pointer' }).click(function(){
			if ( left < $('.carousel04_images li').length - 5 ) {
				$('.carousel04_images li').animate({
					left: '-=120'
				}, function(){
					$('.carousel04_images li:eq('+now+')').trigger('mouseover');
				});
				left++;
				now++;
			}
			return false;
		});
		
		var move = function(){
			if ( now == $('.carousel04_images li').length - 1 ) {
				$('.carousel04_images li').each(function(index){
					$(this).animate({
						left: 120 * index
					}, function(){
						$('.carousel04_images li:eq('+now+')').trigger('mouseover');
					});
				});
				left = 0;
				now = 0;
			} else if ( left > $('.carousel04_images li').length - 6 ){
				now++;
				$('.carousel04_images li:eq('+now+')').trigger('mouseover');
			} else if ( now < left + 2 ) {
				now++;
				$('.carousel04_images li:eq('+now+')').trigger('mouseover');
			} else {
				$('.carousel04_right img').trigger('click');
			}
		}
		var second = 8000;
		var timer = setTimeout(move, second);
	});
})(jQuery);

