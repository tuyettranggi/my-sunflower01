(function($){
	var externalLinkException = [
		'http://www.toyo-sg.com/',
	];
	$(function(){
		if ( jQuery.fn.jquery.match(/(^\d\.\d)/) ) {
			var at = ( RegExp.$1 - 0 >= 1.3 ) ? '' : '@';
			$('a[' + at + 'href^="http"]').each(function(){
				var external = true;
				if ( externalLinkException.length ) {
					for ( var i in externalLinkException ) {
						if ( $(this).attr('href').indexOf( externalLinkException[ i ] ) > -1 ) {
							external = false;
							break;
						}
					}
				}
				if ( external ) {
					$(this).attr('target', '_blank').addClass('externalLink');
				}
			});
		}
	});
})(jQuery);