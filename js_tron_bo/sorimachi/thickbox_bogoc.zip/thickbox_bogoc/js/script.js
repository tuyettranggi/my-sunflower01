$(document).ready(function(){
	$('img.thumb').hover(function(){
		$(this).closest('ul.galleryfR').closest('div.thumList').children('p.galleryfL').children('img.display').attr({"src":"./images/" + $(this).attr("name") + ".jpg"});
		$(this).closest('ul.galleryfR').closest('div.thumList').children('p.galleryfL').children('img.display').hide();
		$(this).closest('ul.galleryfR').closest('div.thumList').children('p.galleryfL').children('img.display').fadeIn();
	});
});