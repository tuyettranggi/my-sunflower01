

$(function(){
var dis = 8;
var so_li = $('.navList li').size();
var widthLI = 71;
var widthUL = widthLI*so_li;
var htm = $('.navList').html();


//_______ position ban dau cho list li

	$('.navList').each(function(){
		$(this).append(htm);
		w = widthUL*2
		$('.navList').css('width',w);
	});		   

//_______ posMax
	var posMax = parseFloat($('.navList li').eq(0).css('left'));
	var tmpPosMax = posMax;

	for(var i3 = 0; i3 <= so_li; i3++){
		tmpPosMax = parseFloat($('.navList li').eq(i3).css('left'));
		if(tmpPosMax > posMax){
		posMax = tmpPosMax;
		}
	}

//_______ posMin
	var posMin = parseFloat($('.navList li').eq(0).css('left'));
	var tmpPosMin = posMin;
	for(var i4 = 0; i4 <= so_li; i4++){
		tmpPosMin = parseFloat($('.navList li').eq(i4).css('left'));
		if(tmpPosMin < posMin){
		posMin = tmpPosMin;
		}
	}


//_______ khi hover next	   
$('.nextButton').click(function() {
	next_loop();
	function next_loop(){
		if(parseFloat($('.navList').css('left'))==-widthUL){ 
			$('.navList').css('left',0);
		}
		$('.navList').animate({
			left: '-='+widthUL
			}, 5000, function() {
				if(parseFloat($('.navList').css('left'))==-widthUL){
					next_loop();
				}
		});
		
		
	}
	
				

});

$('.nextButton').mouseout(function(){
								   alert('x');
		$('.navList').top();
		$('.navList').top();
});
	
//_______ khi hover previous	   
//$('.prevButton').hover(function() {
//	var prevLoop = setInterval(prev_loop,400);
//	function prev_loop(){
//				
//	
//					for(var i2 = 0; i2 < so_li; i2++){
//						w2 = parseFloat($('.navList li').eq(i2).css('left'))+widthLI;
//		
//						if(parseFloat($('.navList li').eq(i2).css('left'))<(widthUL-widthLI)) {
//							$('.navList li').eq(i2).css('left',w2);
//						}
//						else {
//							$('.navList li').eq(i2).css('left',posMin);
//						}
//					};
//	}
//	
//				
//	$('.prevButton').mouseout(function(){
//		clearInterval(prevLoop);						  
//	});
//});



//_______ khi click vao navigator xoa class active dang co san va add vao cho li duoc click
$('.navList li').click(function(){
		$('.navList li.active').removeClass('active');
		$(this).addClass('active');
		// doan nay dung de show hinh slide khi moi load lan dau
		var nID = $('.navList li.active').attr('title');
		$('.galleryList li').hide();
		$('.galleryList li').eq(nID).fadeIn(800);
		//
});


//_______ hieu ung hover button nav
$('.navList li').each(function(index){
	$(this).append('<img class="hover" src="images/img_photo_o.gif" alt="" />');
});

$('.navList li').mouseenter(function(){
	$(this).addClass('show');	
});

$('.navList li').mouseleave(function(){
	$(this).removeClass('show');	
});


// * slider


});/*/*/

