$(function(){
	// imageover
	$('.imgover').each(function(){
		this.osrc = $(this).attr('src');
		this.rollover = new Image();
		this.rollover.src = this.osrc.replace(/(\.gif|\.jpg|\.png)/, "_o$1");
	}).hover(function(){
		$(this).attr('src',this.rollover.src);
	},function(){
		$(this).attr('src',this.osrc);
	});

	// rollover
	$('.pngImgover').mouseover(function(){
		$(this).find('a').addClass('hover');
	});
	$('.pngImgover').mouseout(function(){
		$(this).find('a').removeClass('hover');
	});
	
	
	// iiSlider
	$('#MainView_Area').iiSlider();
	
});