// JavaScript Document
window.addEventListener('load',
function(){
	setTimeout(function(){
	scrollTo(0,1);	
	},100);
}, false);
